"""
sdk_manager.py
مدیریت دانلود و نصب خودکار JDK (Temurin) و Android SDK Command-line Tools
روی ویندوز، بدون نیاز به نصب دستی Android Studio.

همه‌چیز داخل پوشه‌ی مخصوص برنامه در AppData نصب می‌شود تا سیستم کاربر
دستکاری نشود:
    %LOCALAPPDATA%\\ApkBuilder\\jdk
    %LOCALAPPDATA%\\ApkBuilder\\android-sdk
"""

import os
import sys
import json
import zipfile
import shutil
import subprocess
import urllib.request
from pathlib import Path

APP_DATA_DIR = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "ApkBuilder"
JDK_DIR = APP_DATA_DIR / "jdk"
SDK_DIR = APP_DATA_DIR / "android-sdk"

# آدرس‌های رسمی دانلود (قابل تغییر اگر نسخه جدیدتر بخواهید)
JDK_DOWNLOAD_URL = (
    "https://api.adoptium.net/v3/binary/latest/17/ga/windows/x64/jdk/hotspot/normal/eclipse"
    "?project=jdk"
)
# Android SDK command-line tools (نسخه‌ی ویندوز)
CMDLINE_TOOLS_URL = "https://dl.google.com/android/repo/commandlinetools-win-11076708_latest.zip"

# پکیج‌های موردنیاز برای بیلد اکثر پروژه‌های اندروید مدرن
REQUIRED_SDK_PACKAGES = [
    "platform-tools",
    "platforms;android-34",
    "build-tools;34.0.0",
]


def _download_with_progress(url: str, dest_path: Path, progress_callback=None):
    """دانلود یک فایل با گزارش پیشرفت درصدی."""
    def _report(block_num, block_size, total_size):
        if progress_callback and total_size > 0:
            percent = min(100, int(block_num * block_size * 100 / total_size))
            progress_callback(percent)

    urllib.request.urlretrieve(url, dest_path, reporthook=_report)


def is_jdk_installed() -> bool:
    java_exe = JDK_DIR / "bin" / "java.exe"
    return java_exe.exists()


def is_sdk_installed() -> bool:
    sdkmanager = SDK_DIR / "cmdline-tools" / "latest" / "bin" / "sdkmanager.bat"
    platform_tools = SDK_DIR / "platform-tools" / "adb.exe"
    return sdkmanager.exists() and platform_tools.exists()


def get_java_home() -> str:
    return str(JDK_DIR)


def get_android_home() -> str:
    return str(SDK_DIR)


def install_jdk(log=print, progress=None):
    """دانلود و استخراج JDK 17 (Temurin) در صورت عدم وجود."""
    if is_jdk_installed():
        log("JDK از قبل نصب است، رد شد.")
        return

    APP_DATA_DIR.mkdir(parents=True, exist_ok=True)
    zip_path = APP_DATA_DIR / "jdk_temp.zip"

    log("در حال دانلود JDK 17 (Eclipse Temurin)...")
    _download_with_progress(JDK_DOWNLOAD_URL, zip_path, progress)

    log("در حال استخراج JDK...")
    extract_dir = APP_DATA_DIR / "jdk_extract_tmp"
    if extract_dir.exists():
        shutil.rmtree(extract_dir)
    with zipfile.ZipFile(zip_path, "r") as zf:
        zf.extractall(extract_dir)

    # فایل زیپ Temurin یک پوشه‌ی داخلی مثل jdk-17.0.x+y دارد
    inner_dirs = [d for d in extract_dir.iterdir() if d.is_dir()]
    if not inner_dirs:
        raise RuntimeError("ساختار فایل JDK نامعتبر است.")
    if JDK_DIR.exists():
        shutil.rmtree(JDK_DIR)
    shutil.move(str(inner_dirs[0]), str(JDK_DIR))

    shutil.rmtree(extract_dir, ignore_errors=True)
    zip_path.unlink(missing_ok=True)
    log("JDK با موفقیت نصب شد.")


def install_android_sdk(log=print, progress=None):
    """دانلود cmdline-tools و نصب پکیج‌های ضروری از طریق sdkmanager."""
    if not is_jdk_installed():
        raise RuntimeError("ابتدا باید JDK نصب شود (sdkmanager به جاوا نیاز دارد).")

    APP_DATA_DIR.mkdir(parents=True, exist_ok=True)
    zip_path = APP_DATA_DIR / "cmdline_tools_temp.zip"

    cmdline_tools_final = SDK_DIR / "cmdline-tools" / "latest"

    if not cmdline_tools_final.exists():
        log("در حال دانلود Android SDK Command-line Tools...")
        _download_with_progress(CMDLINE_TOOLS_URL, zip_path, progress)

        log("در حال استخراج Command-line Tools...")
        extract_dir = APP_DATA_DIR / "cmdline_extract_tmp"
        if extract_dir.exists():
            shutil.rmtree(extract_dir)
        with zipfile.ZipFile(zip_path, "r") as zf:
            zf.extractall(extract_dir)

        # ساختار لازم: android-sdk/cmdline-tools/latest/bin/...
        cmdline_tools_final.parent.mkdir(parents=True, exist_ok=True)
        src = extract_dir / "cmdline-tools"
        if cmdline_tools_final.exists():
            shutil.rmtree(cmdline_tools_final)
        shutil.move(str(src), str(cmdline_tools_final))

        shutil.rmtree(extract_dir, ignore_errors=True)
        zip_path.unlink(missing_ok=True)
        log("Command-line Tools نصب شد.")
    else:
        log("Command-line Tools از قبل موجود است، رد شد.")

    sdkmanager = cmdline_tools_final / "bin" / "sdkmanager.bat"
    env = os.environ.copy()
    env["JAVA_HOME"] = get_java_home()
    env["ANDROID_HOME"] = get_android_home()
    env["ANDROID_SDK_ROOT"] = get_android_home()

    # پذیرش خودکار همه‌ی لایسنس‌ها
    log("در حال پذیرش لایسنس‌های Android SDK...")
    accept_proc = subprocess.Popen(
        [str(sdkmanager), "--licenses"],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        env=env,
        text=True,
    )
    accept_proc.communicate(input="y\n" * 20)

    for package in REQUIRED_SDK_PACKAGES:
        log(f"در حال نصب پکیج: {package}")
        proc = subprocess.run(
            [str(sdkmanager), package],
            input="y\n",
            capture_output=True,
            text=True,
            env=env,
        )
        if proc.returncode != 0:
            log(f"هشدار: نصب {package} با خطا مواجه شد:\n{proc.stdout}\n{proc.stderr}")
        else:
            log(f"{package} با موفقیت نصب شد.")

    log("نصب Android SDK کامل شد.")


def ensure_all_installed(log=print, progress=None):
    """تابع کمکی: هر دو ابزار را در صورت نیاز نصب می‌کند."""
    if not is_jdk_installed():
        install_jdk(log=log, progress=progress)
    else:
        log("JDK موجود است.")

    if not is_sdk_installed():
        install_android_sdk(log=log, progress=progress)
    else:
        log("Android SDK موجود است.")
