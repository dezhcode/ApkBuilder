"""
build_manager.py
مسئول آماده‌سازی پروژه‌ی اندروید (استخراج zip در صورت نیاز)
و اجرای Gradle برای تولید فایل APK.
"""

import os
import zipfile
import shutil
import subprocess
from pathlib import Path

import sdk_manager


def prepare_project_dir(input_path: str, work_dir: Path) -> Path:
    """
    اگر input_path یک فایل zip باشد، آن را استخراج می‌کند و مسیر پوشه‌ی
    پروژه (جایی که gradlew.bat هست) را برمی‌گرداند. اگر پوشه باشد همان
    را مستقیم برمی‌گرداند.
    """
    input_path = Path(input_path)

    if input_path.is_dir():
        project_root = input_path
    elif input_path.suffix.lower() == ".zip":
        extract_to = work_dir / "extracted_project"
        if extract_to.exists():
            shutil.rmtree(extract_to)
        extract_to.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(input_path, "r") as zf:
            zf.extractall(extract_to)
        project_root = extract_to
    else:
        raise ValueError("ورودی باید یک پوشه‌ی پروژه یا فایل zip باشد.")

    # پیدا کردن پوشه‌ای که واقعا gradlew.bat در آن هست
    # (گاهی zip یک پوشه‌ی داخلی اضافه دارد)
    if (project_root / "gradlew.bat").exists():
        return project_root

    for child in project_root.rglob("gradlew.bat"):
        return child.parent

    raise FileNotFoundError(
        "فایل gradlew.bat در پروژه پیدا نشد. مطمئن شوید سورس یک پروژه‌ی "
        "معتبر Android Studio (Gradle) است."
    )


def run_gradle_build(project_dir: Path, build_type: str = "debug", log=print) -> str:
    """
    اجرای gradlew assembleDebug یا assembleRelease.
    خروجی زنده را از طریق log ارسال می‌کند.
    مسیر نهایی فایل APK را برمی‌گرداند.
    """
    if not sdk_manager.is_jdk_installed() or not sdk_manager.is_sdk_installed():
        raise RuntimeError("JDK یا Android SDK نصب نشده است. ابتدا آن‌ها را نصب کنید.")

    env = os.environ.copy()
    env["JAVA_HOME"] = sdk_manager.get_java_home()
    env["ANDROID_HOME"] = sdk_manager.get_android_home()
    env["ANDROID_SDK_ROOT"] = sdk_manager.get_android_home()
    env["PATH"] = str(Path(env["JAVA_HOME"]) / "bin") + os.pathsep + env.get("PATH", "")

    task = "assembleDebug" if build_type == "debug" else "assembleRelease"

    log(f"در حال اجرای Gradle: {task} ...")
    log("(این مرحله ممکن است چند دقیقه طول بکشد، به‌خصوص بار اول)")

    process = subprocess.Popen(
        ["gradlew.bat", task, "--console=plain"],
        cwd=str(project_dir),
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        env=env,
        text=True,
        bufsize=1,
    )

    for line in process.stdout:
        log(line.rstrip())

    process.wait()

    if process.returncode != 0:
        raise RuntimeError(f"ساخت APK با خطا متوقف شد (کد خروج {process.returncode}).")

    log("Gradle با موفقیت تمام شد. در حال جستجوی فایل APK...")

    apk_dir = project_dir / "app" / "build" / "outputs" / "apk" / build_type
    apk_files = list(apk_dir.rglob("*.apk"))

    if not apk_files:
        # جستجوی گسترده‌تر در صورتی که ساختار ماژول متفاوت باشد
        apk_files = list(project_dir.rglob(f"outputs/apk/{build_type}/**/*.apk"))

    if not apk_files:
        raise FileNotFoundError("Gradle موفق بود اما فایل APK پیدا نشد.")

    return str(apk_files[0])
