"""
main.py
اپلیکیشن ویندوز برای تبدیل سورس کد اندروید به APK
با رابط گرافیکی ساده (Tkinter).

اجرا:
    python main.py

تبدیل به exe (روی ویندوز):
    pip install pyinstaller
    pyinstaller --onefile --windowed --name ApkBuilder main.py
"""

import os
import sys
import threading
import queue
import subprocess
from pathlib import Path

import tkinter as tk
from tkinter import ttk, filedialog, messagebox

import sdk_manager
import build_manager


class ApkBuilderApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("ApkBuilder - تبدیل سورس اندروید به APK")
        self.geometry("760x600")
        self.minsize(700, 550)

        self.log_queue = queue.Queue()
        self.selected_project_path = tk.StringVar()
        self.build_type = tk.StringVar(value="debug")
        self.last_apk_path = None

        self._build_ui()
        self.after(150, self._poll_log_queue)

    # ---------------------------------------------------------- UI LAYOUT
    def _build_ui(self):
        pad = {"padx": 10, "pady": 6}

        # --- بخش ۱: پیش‌نیازها ---
        prereq_frame = ttk.LabelFrame(self, text="۱) پیش‌نیازها (JDK و Android SDK)")
        prereq_frame.pack(fill="x", **pad)

        self.jdk_status_label = ttk.Label(prereq_frame, text="JDK: در حال بررسی...")
        self.jdk_status_label.grid(row=0, column=0, sticky="w", padx=8, pady=4)

        self.sdk_status_label = ttk.Label(prereq_frame, text="Android SDK: در حال بررسی...")
        self.sdk_status_label.grid(row=1, column=0, sticky="w", padx=8, pady=4)

        self.install_btn = ttk.Button(
            prereq_frame, text="بررسی و نصب پیش‌نیازها", command=self._on_install_prereqs
        )
        self.install_btn.grid(row=0, column=1, rowspan=2, padx=8, pady=4)

        self.prereq_progress = ttk.Progressbar(prereq_frame, mode="determinate", maximum=100)
        self.prereq_progress.grid(row=2, column=0, columnspan=2, sticky="ew", padx=8, pady=4)
        prereq_frame.columnconfigure(0, weight=1)

        # --- بخش ۲: انتخاب پروژه ---
        project_frame = ttk.LabelFrame(self, text="۲) انتخاب پروژه اندروید (پوشه یا فایل zip)")
        project_frame.pack(fill="x", **pad)

        entry = ttk.Entry(project_frame, textvariable=self.selected_project_path)
        entry.pack(side="left", fill="x", expand=True, padx=8, pady=8)

        ttk.Button(project_frame, text="انتخاب پوشه...", command=self._browse_folder).pack(
            side="left", padx=4
        )
        ttk.Button(project_frame, text="انتخاب zip...", command=self._browse_zip).pack(
            side="left", padx=4
        )

        # --- بخش ۳: نوع بیلد و اجرا ---
        build_frame = ttk.LabelFrame(self, text="۳) ساخت APK")
        build_frame.pack(fill="x", **pad)

        ttk.Radiobutton(
            build_frame, text="Debug (سریع، برای تست)", variable=self.build_type, value="debug"
        ).pack(side="left", padx=8, pady=6)
        ttk.Radiobutton(
            build_frame, text="Release (برای انتشار)", variable=self.build_type, value="release"
        ).pack(side="left", padx=8, pady=6)

        self.build_btn = ttk.Button(build_frame, text="شروع ساخت APK", command=self._on_build)
        self.build_btn.pack(side="right", padx=8, pady=6)

        # --- بخش ۴: لاگ ---
        log_frame = ttk.LabelFrame(self, text="گزارش عملیات")
        log_frame.pack(fill="both", expand=True, **pad)

        self.log_text = tk.Text(log_frame, wrap="word", state="disabled", bg="#111", fg="#ddd")
        self.log_text.pack(fill="both", expand=True, padx=6, pady=6)

        # --- بخش ۵: نتیجه ---
        result_frame = ttk.Frame(self)
        result_frame.pack(fill="x", **pad)

        self.result_label = ttk.Label(result_frame, text="")
        self.result_label.pack(side="left")

        self.open_folder_btn = ttk.Button(
            result_frame, text="باز کردن پوشه APK", command=self._open_apk_folder, state="disabled"
        )
        self.open_folder_btn.pack(side="right")

        self._refresh_prereq_status()

    # ---------------------------------------------------------- HELPERS
    def _log(self, message: str):
        self.log_queue.put(message)

    def _poll_log_queue(self):
        while not self.log_queue.empty():
            msg = self.log_queue.get_nowait()
            self.log_text.configure(state="normal")
            self.log_text.insert("end", msg + "\n")
            self.log_text.see("end")
            self.log_text.configure(state="disabled")
        self.after(150, self._poll_log_queue)

    def _refresh_prereq_status(self):
        jdk_ok = sdk_manager.is_jdk_installed()
        sdk_ok = sdk_manager.is_sdk_installed()
        self.jdk_status_label.config(
            text=f"JDK: {'✅ نصب شده' if jdk_ok else '❌ نصب نشده'}"
        )
        self.sdk_status_label.config(
            text=f"Android SDK: {'✅ نصب شده' if sdk_ok else '❌ نصب نشده'}"
        )

    def _browse_folder(self):
        path = filedialog.askdirectory(title="پوشه‌ی پروژه اندروید را انتخاب کنید")
        if path:
            self.selected_project_path.set(path)

    def _browse_zip(self):
        path = filedialog.askopenfilename(
            title="فایل zip سورس اندروید را انتخاب کنید",
            filetypes=[("Zip files", "*.zip")],
        )
        if path:
            self.selected_project_path.set(path)

    def _open_apk_folder(self):
        if self.last_apk_path:
            folder = str(Path(self.last_apk_path).parent)
            if sys.platform.startswith("win"):
                os.startfile(folder)  # noqa
            else:
                subprocess.run(["xdg-open", folder])

    # ---------------------------------------------------------- ACTIONS
    def _on_install_prereqs(self):
        self.install_btn.config(state="disabled")

        def worker():
            try:
                sdk_manager.ensure_all_installed(
                    log=self._log,
                    progress=lambda p: self.prereq_progress.configure(value=p),
                )
                self._log("✅ همه‌ی پیش‌نیازها آماده هستند.")
            except Exception as exc:  # noqa
                self._log(f"❌ خطا در نصب پیش‌نیازها: {exc}")
                messagebox.showerror("خطا", str(exc))
            finally:
                self.install_btn.config(state="normal")
                self._refresh_prereq_status()

        threading.Thread(target=worker, daemon=True).start()

    def _on_build(self):
        project_path = self.selected_project_path.get().strip()
        if not project_path:
            messagebox.showwarning("هشدار", "ابتدا یک پوشه یا فایل zip پروژه انتخاب کنید.")
            return

        if not sdk_manager.is_jdk_installed() or not sdk_manager.is_sdk_installed():
            messagebox.showwarning(
                "هشدار", "ابتدا باید JDK و Android SDK را نصب کنید (بخش ۱)."
            )
            return

        self.build_btn.config(state="disabled")
        self.open_folder_btn.config(state="disabled")
        self.result_label.config(text="")

        def worker():
            try:
                work_dir = Path(sdk_manager.APP_DATA_DIR) / "work"
                work_dir.mkdir(parents=True, exist_ok=True)

                self._log("در حال آماده‌سازی پروژه...")
                project_dir = build_manager.prepare_project_dir(project_path, work_dir)
                self._log(f"پروژه پیدا شد در: {project_dir}")

                apk_path = build_manager.run_gradle_build(
                    project_dir, build_type=self.build_type.get(), log=self._log
                )

                self.last_apk_path = apk_path
                self._log(f"🎉 فایل APK با موفقیت ساخته شد:\n{apk_path}")
                self.result_label.config(text=f"APK ساخته شد: {apk_path}")
                self.open_folder_btn.config(state="normal")

            except Exception as exc:  # noqa
                self._log(f"❌ خطا: {exc}")
                messagebox.showerror("خطا در ساخت APK", str(exc))
            finally:
                self.build_btn.config(state="normal")

        threading.Thread(target=worker, daemon=True).start()


if __name__ == "__main__":
    app = ApkBuilderApp()
    app.mainloop()
